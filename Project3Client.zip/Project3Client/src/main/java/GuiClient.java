import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.util.HashMap;

public class GuiClient extends Application {

	TextField c1;
	Button b1;
	HashMap<String, Scene> sceneMap;
	VBox clientBox;
	Client clientConnection;
	HBox fields;
	ComboBox<String> listUsers;

	ListView<String> listItems;

	Scene loginScene;
	Scene mainScene;
	BorderPane loginPane;
	BorderPane mainPane;
	VBox vLoginCenter;
	TextField txtLoginUserName;
	Button btnLogin;

	boolean validUsername = false;
	String currentUsername;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {

		clientConnection = new Client(data -> {
			Platform.runLater(() -> {
				switch (data.type) {
					case NEWUSER:
						//the not check prevents the first user that joins being named null
						if (!listUsers.getItems().contains(data.recipient) && !data.recipient.equals(currentUsername)) {
							listUsers.getItems().add(data.recipient);
							listItems.getItems().add((data.recipient) + " has joined!");
						}
						break;
					case DISCONNECT:
						listUsers.getItems().remove(data.recipient);
						listItems.getItems().add(data.recipient + " has disconnected!");
						break;
					case TEXT:
							listItems.getItems().add(data.message);
						break;
					case USERNAME:
						//If username is not taken then currentUsername stores username client enters
						validUsername = data.message.equals("valid");
						if (validUsername) {
							currentUsername = txtLoginUserName.getText();
							//Goes to next scene where we could put our game scene maybe
							primaryStage.setScene(sceneMap.get("main"));
							primaryStage.setTitle("Messaging");
						} else {
							//Asks to enter another if taken
							txtLoginUserName.clear();
							txtLoginUserName.setPromptText("Username taken, try another");
						}
				}
			});
		});

		clientConnection.start();

		listUsers = new ComboBox<String>();
		listUsers.getItems().add("To All");
		listUsers.setValue("To All");
		listItems = new ListView<String>();


		c1 = new TextField();
		b1 = new Button("Send");
		fields = new HBox(listUsers, b1);
		b1.setOnAction(e -> {
			String recipient = listUsers.getValue();
			//Prints the message with the senders username in front of it
			if (recipient.equals("To All")) {
				clientConnection.send(new Message("All", currentUsername + ": " + c1.getText()));
			}
			else {
				//Sends individual message, so far also prints on senders screen
				clientConnection.send(new Message(recipient, currentUsername + ": " + c1.getText()));
			}
			listItems.getItems().add(currentUsername + ": " + c1.getText());
			c1.clear();
		});

		clientBox = new VBox(10, c1, fields, listItems);
		clientBox.setStyle("-fx-background-color: blue;" + "-fx-font-family: 'serif';");


		txtLoginUserName = new TextField();
		txtLoginUserName.setPromptText("Enter your username");
		btnLogin = new Button("Login");
		btnLogin.setOnAction(e -> {
			//Sends username message if login box is not empty
			String username = txtLoginUserName.getText();
			if (!username.isEmpty()) {
				clientConnection.send(new Message(username, MessageType.USERNAME));
			}
		});

		//Scene set up, put into sceneMap
		vLoginCenter = new VBox(10, txtLoginUserName, btnLogin);
		vLoginCenter.setStyle("-fx-background-color: blue;" + "-fx-font-family: 'serif';");
		loginScene = new Scene(vLoginCenter, 400, 300);

		mainScene = new Scene(clientBox, 400, 300);

		sceneMap = new HashMap<>();
		sceneMap.put("login", loginScene);
		sceneMap.put("main", mainScene);
		primaryStage.setScene(sceneMap.get("login"));
		primaryStage.setTitle("Login");
		primaryStage.show();
	}
}