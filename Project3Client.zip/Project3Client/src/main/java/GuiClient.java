import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.util.HashMap;

public class GuiClient extends Application{

	TextField c1;
	Button b1;
	HashMap<String, Scene> sceneMap;
	VBox clientBox;
	Client clientConnection;
	HBox fields;
	ComboBox<String> listUsers;

	ListView<String> listItems;

	Scene loginScene;
	BorderPane loginPane;
	VBox vLoginCenter;
	TextField txtLoginUserName;
	Button btnLogin;

	boolean validUsername = false;
	String currentUsername;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		clientConnection = new Client(data->{
			Platform.runLater(()->{
				switch (data.type){
					case NEWUSER:
						if(!listUsers.getItems().contains(data.recipient)) {
							listUsers.getItems().add(data.recipient);
							listItems.getItems().add(data.recipient + " has joined!");
						}
						break;
					case DISCONNECT:
						listUsers.getItems().remove(data.recipient);
						listItems.getItems().add(data.recipient + " has disconnected!");
						break;
					case TEXT:
						listItems.getItems().add(data.recipient+": "+data.message);
						break;
					case USERNAME:
						validUsername = data.message.equals("valid");
						if (validUsername) {
							currentUsername = txtLoginUserName.getText();
							primaryStage.setScene(sceneMap.get("main"));
						} else {
							txtLoginUserName.clear();
							txtLoginUserName.setPromptText("Username taken - try another");
						}
				}
			});
		});

		clientConnection.start();


		listUsers = new ComboBox<String>();
		listUsers.getItems().add("To All");
		listUsers.setValue("To All");
		listItems = new ListView<String>();

		c1 = new TextField();
		b1 = new Button("Send");
		fields = new HBox(listUsers, b1);
		b1.setOnAction(e->{
			clientConnection.send(new Message(listUsers.getValue(), c1.getText()));
			c1.clear();
		});

		clientBox = new VBox(10, c1, fields, listItems);
		clientBox.setStyle("-fx-background-color: blue;"+"-fx-font-family: 'serif';");


		txtLoginUserName = new TextField();
		txtLoginUserName.setPromptText("Enter your username");
		btnLogin = new Button("Login");
		btnLogin.setOnAction(e -> {
			String username = txtLoginUserName.getText();
			if (!username.isEmpty()) {
				clientConnection.send(new Message(username, MessageType.USERNAME));
			}
		});

		VBox loginBox = new VBox(10, txtLoginUserName, btnLogin);
		loginBox.setStyle("-fx-background-color: blue;"+"-fx-font-family: 'serif';");

		sceneMap = new HashMap<>();
		sceneMap.put("login", new Scene(loginBox, 400, 300));
		sceneMap.put("main", new Scene(clientBox, 400, 300));

		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent t) {
				Platform.exit();
				System.exit(0);
			}
		});

		primaryStage.setScene(sceneMap.get("login"));
		primaryStage.setTitle("Client Login");
		primaryStage.show();
	}
}
