import java.io.Serializable;

public class Message implements Serializable {
    static final long serialVersionUID = 42L;
    MessageType type;
    String message;
    String recipient;
    int row;
    int column;
    Boolean MyTurn;

    public Message(String i, boolean connect){
        if(connect) {
            type = MessageType.NEWUSER;
            message = "User "+i+" has joined!";
            recipient = i;
        } else {
            type = MessageType.DISCONNECT;
            message = "User "+i+" has disconnected!";
            recipient = i;
        }
    }

    //Used for sending username to server
    public Message(String mess, MessageType type){
        this.type = type;
        message = mess;
        recipient = "Server";
    }

    // Used for sending from server to client
    public Message(String color, int r, int c, Boolean MyTurn){
        this.type = MessageType.MOVE;
        message = color;
        this.row = r;
        this.column = c;
        this.MyTurn = MyTurn;
    }

    // Used for sending from client to server
    public Message(int c){
        type = MessageType.MOVE;
        message = "";
        recipient = "Server";
        column = c;
    }

    public Message(MessageType type){
        this.type = type;
        message = "";
    }

    public Message(String rec, String mess){
        type = MessageType.TEXT;
        message = mess;
        recipient = rec;
    }
}
