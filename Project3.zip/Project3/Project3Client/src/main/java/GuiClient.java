import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.util.HashMap;
import java.util.Vector;

public class GuiClient extends Application {

	TextField c1;
	Button b1;
	HashMap<String, Scene> sceneMap;
	VBox clientBox;
	Client clientConnection;
	HBox fields;
	ComboBox<String> listUsers;

	ListView<String> listItems;

	Scene loginScene;
	Scene mainScene;
	BorderPane loginPane;
	BorderPane mainPane;
	HBox hLoginCenter;
	TextField txtLoginUserName;
	Button btnLogin;

	Scene joinScene;
	BorderPane joinPane;
	VBox vJoinCenter;
	Button btnJoin;

	Scene gameScene;
	BorderPane gamePane;
	HBox hGameBoard;
	Vector<VBox> vGameBoardColumns; // 7 cols
	Label lblGameStatus;
	HBox hMoveBtns;
	Vector<Button> btnCol;
	VBox vGameSide, vMessageSide;


	boolean validUsername = false;
	String currentUsername;

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {

		clientConnection = new Client(data -> {
			Platform.runLater(() -> {
				switch (data.type) {
					case NEWUSER:
						//the not check prevents the first user that joins being named null
						if (!listUsers.getItems().contains(data.recipient) && !data.recipient.equals(currentUsername)) {
							listUsers.getItems().add(data.recipient);
							listItems.getItems().add((data.recipient) + " has joined!");
						}
						break;
					case DISCONNECT:
						listUsers.getItems().remove(data.recipient);
						listItems.getItems().add(data.recipient + " has disconnected!");
						break;
					case TEXT:
							listItems.getItems().add(data.message);
						break;
					case USERNAME:
						//If username is not taken then currentUsername stores username client enters
						validUsername = data.message.equals("valid");
						if (validUsername) {
							currentUsername = txtLoginUserName.getText();
							//Goes to next scene where we could put our game scene maybe
							primaryStage.setScene(sceneMap.get("join"));
							primaryStage.setTitle("Join a Game");
						} else {
							//Asks to enter another if taken
							txtLoginUserName.clear();
							txtLoginUserName.setPromptText("Username taken, try another");
						}
						break;
					case JOIN:
                        switch (data.message) {
                            case "red":
                                primaryStage.setScene(sceneMap.get("game"));
                                lblGameStatus.setText("Waiting for Opponent to join");
                                for (Button b : btnCol) {
                                    b.setDisable(true);
                                }
                                break;
                            case "game started":
                                for (Button b : btnCol) {
                                    b.setDisable(false);
                                }
                                lblGameStatus.setText("Your Move");
                                break;
                            case "black":
                                primaryStage.setScene(sceneMap.get("game"));
                                for (Button b : btnCol) {
                                    b.setDisable(true);
                                }
                                lblGameStatus.setText("Waiting for Opponent's Move");
                                break;
							default:
								primaryStage.setScene(sceneMap.get("game"));
								lblGameStatus.setText("error");
                        }
						break;

				}
			});
		});

		clientConnection.start();

		listUsers = new ComboBox<String>();
		listUsers.getItems().add("To All");
		listUsers.setValue("To All");
		listItems = new ListView<String>();


		c1 = new TextField();
		b1 = new Button("Send");
		fields = new HBox(listUsers, b1);
		b1.setOnAction(e -> {
			String recipient = listUsers.getValue();
			//Prints the message with the senders username in front of it
			if (recipient.equals("To All")) {
				clientConnection.send(new Message("All", currentUsername + ": " + c1.getText()));
			}
			else {
				//Sends individual message, so far also prints on senders screen
				clientConnection.send(new Message(recipient, currentUsername + ": " + c1.getText()));
			}
			listItems.getItems().add(currentUsername + ": " + c1.getText());
			c1.clear();
		});

		clientBox = new VBox(10, c1, fields, listItems);
		clientBox.setStyle("-fx-background-color: blue;" + "-fx-font-family: 'serif';");

		//
 		// Login Scene
		//
		txtLoginUserName = new TextField();
		txtLoginUserName.setPromptText("Enter your username");
		btnLogin = new Button("Login");
		btnLogin.setOnAction(e -> {
			//Sends username message if login box is not empty
			String username = txtLoginUserName.getText();
			if (!username.isEmpty()) {
				clientConnection.send(new Message(username, MessageType.USERNAME));
			}
		});

		//Scene set up, put into sceneMap
		hLoginCenter = new HBox(10, txtLoginUserName, btnLogin);
		hLoginCenter.setStyle("-fx-background-color: blue;" + "-fx-font-family: 'serif';");

		loginPane = new BorderPane();
		loginPane.setPadding(new Insets(50));
		loginPane.setCenter(hLoginCenter);
		loginScene = new Scene(loginPane, 400, 300);
		//
 		// End of Login Scene
		//


		//
 		// Join Game Scene
		//

		btnJoin = new Button("Join a Game");
		btnJoin.setOnAction(e -> { clientConnection.send(new Message(MessageType.JOIN)); });
		vJoinCenter = new VBox(10, btnJoin);
		joinPane = new BorderPane();
		joinPane.setPadding(new Insets(50));
		joinPane.setCenter(vJoinCenter);
		joinScene = new Scene(joinPane, 400, 300);

		//
 		// End of Join Game Scene
		//

		//
 		// Game Scene
		//

		// create the game board columns and fill them with white hboxes
		// create the move btns for each column
		vGameBoardColumns = new Vector<>();
		btnCol = new Vector<>();
		for (int i = 0; i < 7; i++) {
			VBox vTemp = new VBox(10);
			//vTemp.setStyle("-fx-background-color: #ffcc00;");
			for (int j = 0; j < 6; j++) {
				HBox hTemp = new HBox(10);
				hTemp.setStyle("-fx-background-color: white;");
				hTemp.setPrefSize(20,20);
				vTemp.getChildren().add(hTemp);
			}
			vGameBoardColumns.add(vTemp);

			Button btnTemp = new Button(String.valueOf(i));
			btnTemp.setOnAction(e -> {});
			btnTemp.setPrefSize(20,20);
			btnCol.add(btnTemp);
		}
		// add move buttons to the hbox
		hMoveBtns = new HBox(10, btnCol.get(0), btnCol.get(1), btnCol.get(2), btnCol.get(3),
				btnCol.get(4), btnCol.get(5), btnCol.get(6));
		// add the columns to the board
		hGameBoard = new HBox(10, vGameBoardColumns.get(0),
				vGameBoardColumns.get(1), vGameBoardColumns.get(2), vGameBoardColumns.get(3),
				vGameBoardColumns.get(4),  vGameBoardColumns.get(5), vGameBoardColumns.get(6));
		hGameBoard.setStyle("-fx-background-color: yellow");
		hGameBoard.setPadding(new Insets(10));
		hGameBoard.setPrefWidth(220);

		lblGameStatus = new Label("Game Status");

		VBox vGameSide = new VBox(10, hMoveBtns, hGameBoard, lblGameStatus);
		gamePane = new BorderPane();
		gamePane.setCenter(vGameSide);
		gameScene = new Scene(gamePane, 500, 500);


		//
 		// End of Game Scene
		//



		mainScene = new Scene(clientBox, 400, 300);

		sceneMap = new HashMap<>();
		sceneMap.put("login", loginScene);
		sceneMap.put("main", mainScene);
		sceneMap.put("join", joinScene);
		sceneMap.put("game", gameScene);
		primaryStage.setScene(sceneMap.get("login"));
		primaryStage.setTitle("Login");
		primaryStage.show();
	}
}