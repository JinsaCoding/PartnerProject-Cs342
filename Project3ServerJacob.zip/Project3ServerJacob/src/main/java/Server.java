import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.scene.control.ListView;

import javax.lang.model.type.NullType;
/*
 * Clicker: A: I really get it    B: No idea what you are talking about
 * C: kind of following
 */

public class Server {

	int count = 1;
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	HashMap<String, ClientThread> clientMap = new HashMap<>();
	ArrayList<GameBoard> gameBoards = new ArrayList<>();

	TheServer server;
	private Consumer<Message> callback;


	Server(Consumer<Message> call) {

		callback = call;
		server = new TheServer();
		server.start();
	}


	public class TheServer extends Thread {

		public void run() {

			try (ServerSocket mysocket = new ServerSocket(5555);) {
				System.out.println("Server is waiting for a client!");


				while (true) {

					ClientThread c = new ClientThread(mysocket.accept(), count);
					clients.add(c);
					c.start();

					count++;

				}
			} catch (Exception e) {
				callback.accept(new Message("Server did not launch"));
			}
		}
	}

	class GameBoard implements Serializable {
		Character[][] board;
		ClientThread red;
		ClientThread black;

		boolean gameStarted;
		boolean redTurn; // red always starts

		/*
		Empty Board
			6|x x x x x x x x
			5|x x x x x x x x
			4|x x x x x x x x
			3|x x x x x x x x
			2|x x x x x x x x
			1|x x x x x x x x
			0|x x x x x x x x
			  _ _ _ _ _ _ _ _
		 	  0 1 2 3 4 5 6 7

		 	  r = the red client's piece
		 	  b = the black client's piece
		 */
		// set the red player as the thread creating the game
		// make the board and wait for other player to join
		GameBoard(ClientThread r) {
			this.red = r;
			redTurn = true;
			gameStarted = false;
			this.red.gameBoard = this;
			this.black = null;

			clearBoard();
		}

		public boolean JoinGame(ClientThread b) {
			// if there isn't a black player in the game have them join as black and return true
			if (this.black == null) {
				this.black = b;
				this.black.gameBoard = this;
				this.gameStarted = true;
				// notify the black player that they are black
				Message toBlack = new Message("black", MessageType.JOIN);
				// notify the red player that the game has started
				Message toRed = new Message("game started", MessageType.JOIN);
				// display that black and red started a game
				String strToServer = black.username + " started a game with " + red.username;
				Message toServer = new Message(strToServer, MessageType.TEXT);

				try {
					this.black.out.writeObject(toBlack);
					this.red.out.writeObject(toRed);
					callback.accept(toServer);
				} catch (IOException e) {
					System.out.println("JOIN (existing game) error");
				}
				this.gameStarted = true;
				return true;
			} else {
				return false;
			}
		}

		public void NewGame() {
			redTurn = true;

			clearBoard();
		}

		// create a new empty board
		private void clearBoard() {
			board = new Character[][]{
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
			};
		}
		//These all check for the pieces in a row in the respective direction
		//Checks are made to make sure the new location we're checking is not out of bounds
		//Pretty straightforward, just basic math stuff with arrays
		private int checkDiagonalBottomLeft(int currRow, int currColumn, char piece, int pieceCount){
			pieceCount = 1;
			if (board[currRow - 1][currColumn - 1] == piece && currRow - 1 >= 0 && currColumn - 1 >= 0) {
				pieceCount++;
			}
			if (board[currRow - 1][currColumn - 1] == piece && board[currRow - 2][currColumn - 2] == piece && currRow - 2 >= 0
					&& currColumn - 2 >= 0) {
				pieceCount ++;
			}
			if (board[currRow - 1][currColumn - 1] == piece && board[currRow - 2][currColumn - 2] == piece &&
					board[currRow - 3][currColumn - 3] == piece && currRow - 3 >= 0 && currColumn - 3 >= 0) {
				pieceCount++;
			}
			return pieceCount;

		}
		private int checkDiagonalTopRight(int currRow, int currColumn, char piece, int pieceCount){
			pieceCount = 1;
			if (board[currRow + 1][currColumn + 1] == piece && currRow + 1 <= 6 && currColumn + 1 <= 6) {
				pieceCount++;
			}
			if (board[currRow + 1][currColumn + 1] == piece && board[currRow + 2][currColumn + 2] == piece
					&& currRow + 2 <= 6 && currColumn + 2 <= 6) {
				pieceCount ++;
			}
			if (board[currRow + 1][currColumn + 1] == piece && board[currRow + 2][currColumn + 2] == piece
					&& board[currRow + 3][currColumn + 3] == piece && currRow + 3 <= 6 && currColumn + 3 <= 6) {
				pieceCount++;
			}
			return pieceCount;
		}
		private int checkDiagonalTopLeft(int currRow, int currColumn, char piece, int pieceCount){
			pieceCount = 1;
			if (board[currRow + 1][currColumn - 1] == piece && currRow + 1 <= 6 && currColumn - 1 >= 0) {
				pieceCount++;
			}
			if (board[currRow + 1][currColumn - 1] == piece && board[currRow - 2][currColumn - 2] == piece && currRow - 2 >= 0
					&& currColumn - 2 >= 0) {
				pieceCount ++;
			}
			if (board[currRow - 1][currColumn - 1] == piece && board[currRow - 2][currColumn - 2] == piece &&
					board[currRow - 3][currColumn - 3] == piece && currRow - 3 >= 0 && currColumn - 3 >= 0) {
				pieceCount++;
			}
			return pieceCount;

		}
		private int checkDiagonalBottomRight(int currRow, int currColumn, char piece, int pieceCount){
			pieceCount = 1;
			if (board[currRow - 1][currColumn + 1] == piece && currRow - 1 >= 0 && currColumn + 1 <= 6) {
				pieceCount++;
			}
			if (board[currRow - 1][currColumn + 1] == piece && board[currRow - 2][currColumn + 2] == piece && currRow - 2 >= 0
					&& currColumn + 2 <= 6) {
				pieceCount ++;
			}
			if (board[currRow - 1][currColumn + 1] == piece && board[currRow - 2][currColumn + 2] == piece &&
					board[currRow - 3][currColumn + 3] == piece && currRow - 3 >= 0 && currColumn + 3 <= 6) {
				pieceCount++;
			}
			return pieceCount;

		}
		private int checkBottom(int currRow, int currColumn, char piece, int pieceCount){
			pieceCount = 1;
			if (board[currRow + 1][currColumn] == piece && currRow + 1 <= 6){
				pieceCount++;
			}
			if (board[currRow + 1][currColumn] == piece && board[currRow + 2][currColumn] == piece && currRow + 2 <= 6){
				pieceCount++;
			}
			if(board[currRow + 1][currColumn] == piece && board[currRow + 2][currColumn] == piece &&
					board[currRow + 3][currColumn] == piece && currRow + 3 <= 6){
				pieceCount++;
			}
			return pieceCount;
		}
		//Stores each directional check in a variable and then adds them up,
		//used on the current piece so if it adds up to 4 or greater, there must be 4 in a row for a wimn
		private boolean checkForWin(int currRow, int currColumn, char piece) {
			int count = 0;
			int bottom = checkBottom(currRow, currColumn, piece, count);
			int bottomLeft = checkDiagonalBottomLeft(currRow, currColumn, piece, count);
			int bottomRight = checkDiagonalBottomRight(currRow, currColumn, piece, count);
			int topLeft = checkDiagonalTopLeft(currRow, currColumn, piece, count);
			int topRight = checkDiagonalTopRight(currRow, currColumn, piece, count);

			if(bottom + bottomLeft + bottomRight + topLeft + topRight >= 4){
				return true;
			}
			return false;
		}

		private boolean makeMove(int column, boolean isRed) {

			//Starts from, bottom and finds first available open space
			for (int row = 6; row >= 0; row--) {
				if (board[row][column] == 'x') {
					//Places respective piece based on turn
					if (redTurn) {
						board[row][column] = 'r';
						//Check for a win on the current piece everytime a new one is placed, sends message and returns
						//true for a win
						if(checkForWin(row, column, 'r')){
							try{
								black.out.writeObject(new Message("Red got 4 in a row and won.", MessageType.TEXT));
								red.out.writeObject(new Message("You won!"));
							}catch(IOException e){
								System.err.println("MakeMove error");
							}
							return true;
						}
					} else {
						board[row][column] = 'b';
						if (checkForWin(row, column, 'b')){
							try{
								black.out.writeObject(new Message("You won!", MessageType.TEXT));
								red.out.writeObject(new Message("Black got 4 in a row and won."));
							}catch(IOException e){
								System.err.println("MakeMove error");
							}
							return true;
						}
					}
					//Switch turn and return true
					redTurn = !redTurn;
					return true;
				}
			}
			//Otherwise the column is full
			return false;
		}


	}


	class ClientThread extends Thread {


		Socket connection;
		int count;
		ObjectInputStream in;
		ObjectOutputStream out;
		String username;
		GameBoard gameBoard;


		ClientThread(Socket s, int count) {
			this.connection = s;
			this.count = count;
		}

		public void updateClients(Message message) {
			switch (message.type) {
				case TEXT:
					if (message.recipient.equals("All")) {
						for (ClientThread client : clients) {
							if (client != this) {
								try {
									client.out.writeObject(message);
								} catch (Exception e) {
									System.err.println("TEXT error");
								}
							}
						}
					} else {
						ClientThread recipient = clientMap.get(message.recipient);
						if (recipient != null) {
							try {
								recipient.out.writeObject(message);
							} catch (Exception e) {
								System.err.println("TEXT error");
							}
						}
					}
					break;
				case NEWUSER:
					for (ClientThread t : clients) {
						if (this != t) {
							try {
								t.out.writeObject(message);
							} catch (Exception e) {
								System.err.println("NEWUSER Error");
							}
						}
					}
					break;
				case USERNAME:
					//Checks if name is not already taken and puts user as key and current thread as value
					if (!clientMap.containsKey(message.message)) {
						try {
							clientMap.put(message.message, this);
							this.username = message.message;
							updateClients(new Message(username, true));
							Message m = new Message("valid", MessageType.USERNAME);
							this.out.writeObject(m);
							Message n = new Message(username + " has joined!", MessageType.TEXT);
							n.recipient = "All";
							callback.accept(n);
						} catch (Exception e) {
							System.err.println("USERNAME error");
						}
					} else {
						try {
							Message invalidMsg = new Message("invalid", MessageType.USERNAME);
							this.out.writeObject(invalidMsg);
						} catch (Exception e) {
							System.err.println("USERNAME error");
						}
					}
					break;
				case JOIN:

					for (GameBoard gb : gameBoards) {
						if (gb.JoinGame(this)) {
							// messages handled in the gameboard join method
							this.gameBoard = gb;
							break;
						}
					}
					if (this.gameBoard != null) {
						break;
					}
					// if they couldn't join a game then create one
					GameBoard gb = new GameBoard(this);
					gameBoards.add(gb);
					// display that the client thread is waiting for an opponent
					Message m = new Message(this.username + " is waiting for an opponent", MessageType.TEXT);
					callback.accept(m);


					try {
						// let the thread know that they are red
						Message n = new Message("red", MessageType.JOIN);
						this.out.writeObject(n);
					} catch (Exception e) {
						System.err.println("JOIN (create gameboard) Error");
					}


					break;
				case DISCONNECT:
					//map iterating to find the username
					//Map.Entry iterates through both parts of the map since we need to get the username which is the key
					//And we are looking for the current thread
					for (Map.Entry<String, ClientThread> t : clientMap.entrySet()) {
						if (t.getValue() == this) {
							clientMap.remove(t.getKey());
							clientMap.remove(t.getValue());
						}
					}
			}
		}

		public void run() {

			try {
				in = new ObjectInputStream(connection.getInputStream());
				out = new ObjectOutputStream(connection.getOutputStream());
				connection.setTcpNoDelay(true);
			} catch (Exception e) {
				System.out.println("Streams not open");
			}

			updateClients(new Message(username, true));

			while (true) {
				try {
					Message data = (Message) in.readObject();
					callback.accept(data);
					updateClients(data);
				} catch (Exception e) {
					e.printStackTrace();
					Message discon = new Message(username, false);
					callback.accept(discon);
					updateClients(discon);
					clients.remove(this);
					break;
				}
			}
		}


	}
}