import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.scene.control.ListView;

import javax.lang.model.type.NullType;
/*
 * Clicker: A: I really get it    B: No idea what you are talking about
 * C: kind of following
 */

public class Server {

	int count = 1;
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	HashMap<String, ClientThread> clientMap = new HashMap<>();
	ArrayList<GameBoard> gameBoards = new ArrayList<>();

	TheServer server;
	private Consumer<Message> callback;


	Server(Consumer<Message> call) {

		callback = call;
		server = new TheServer();
		server.start();
	}


	public class TheServer extends Thread {

		public void run() {

			try (ServerSocket mysocket = new ServerSocket(5555);) {
				System.out.println("Server is waiting for a client!");


				while (true) {

					ClientThread c = new ClientThread(mysocket.accept(), count);
					clients.add(c);
					c.start();

					count++;

				}
			} catch (Exception e) {
				callback.accept(new Message("Server did not launch"));
			}
		}
	}

	class GameBoard implements Serializable {
		Character[][] board;
		ClientThread red;
		ClientThread black;

		boolean gameStarted;
		boolean redTurn; // red always starts

		/*
		Empty Board
			5|x x x x x x x
			4|x x x x x x x
			3|x x x x x x x
			2|x x x x x x x
			1|x x x x x x x
			0|x x x x x x x
			  _ _ _ _ _ _ _
		 	  0 1 2 3 4 5 6

		 	  r = the red client's piece
		 	  b = the black client's piece
		 */
		// set the red player as the thread creating the game
		// make the board and wait for other player to join
		GameBoard(ClientThread r) {
			this.red = r;
			redTurn = true;
			gameStarted = false;
			this.red.gameBoard = this;
			this.black = null;

			clearBoard();
		}

		public boolean JoinGame(ClientThread b) {
			// if there isn't a black player in the game have them join as black and return true
			if (this.black == null) {
				this.black = b;
				this.black.gameBoard = this;
				this.gameStarted = true;
				// notify the black player that they are black
				Message toBlack = new Message("black", MessageType.JOIN);
				// notify the red player that the game has started
				Message toRed = new Message("game started", MessageType.JOIN);
				// display that black and red started a game
				String strToServer = black.username + " started a game with " + red.username;
				Message toServer = new Message(strToServer, MessageType.TEXT);

				try {
					this.black.out.writeObject(toBlack);
					this.red.out.writeObject(toRed);
					callback.accept(toServer);
				} catch (IOException e) {
					System.out.println("JOIN (existing game) error");
				}
				this.gameStarted = true;
				return true;
			} else {
				return false;
			}
		}

		public void NewGame() {
			redTurn = true;

			clearBoard();
		}

		// create a new empty board
		private void clearBoard() {
			board = new Character[][]{
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
					{'x', 'x', 'x', 'x', 'x', 'x', 'x'},
			};
		}

		private boolean isBoardFull() {
			for (int col = 0; col < 7; col++) {
				if (board[0][col] == 'x') {  // If the top row has an empty spot
					return false;  // There is still space in the column
				}
			}
			return true;  // No empty spots found, board is full
		}

		// take in current row and col
		// also take the row and col direction, 1 for going down, -1 for going up, and 0 to stay in that row/col
		// also use piece character to know when to stop
		private int countDirection(int row, int col, int rowDir, int colDir, char piece) {
			// calculate the new row and col from the direction
			int count = 0;
			int newRow = row + rowDir;
			int newCol = col + colDir;
			// make sure row and col are in bounds and that the piece is the color we are looking for
			while (newRow >= 0 && newRow < 6 && newCol >= 0 && newCol < 7 && board[newRow][newCol] == piece) {
				count++;
				newRow += rowDir;
				newCol += colDir;
			}

			return count;
		}
		// returns true if any of the directions sum to 3 or more since count direction does not include the piece just placed
		private boolean checkForWin(int currRow, int currColumn, char piece) {
			return (countDirection(currRow, currColumn, 1, 0, piece) > 2) || // vertical
					(countDirection(currRow, currColumn, 0, 1, piece) + countDirection(currRow, currColumn, 0, -1, piece) > 2) || // horizontal
					(countDirection(currRow, currColumn, 1, 1, piece) + countDirection(currRow, currColumn, -1, -1, piece) > 2) || // diagonal /
					(countDirection(currRow, currColumn, 1, -1, piece) + countDirection(currRow, currColumn, -1, 1, piece) > 2);   // diagonal \
        }

		//private boolean makeMove(int column, boolean isRed) {
		private void makeMove(int column, ClientThread caller) {
			// make sure it is the client's move
			if((redTurn && caller != red) || (!redTurn && caller != black)) {
				try {
					caller.out.writeObject(new Message("invalid", MessageType.MOVE));
				}
				catch(IOException e){
					System.err.println("Tried to place a piece when not their turn");
				}
				return;
			}

			// Check if the column is valid
			if (column < 0 || column > 6) {
				try {
					caller.out.writeObject(new Message("invalid", MessageType.MOVE));
				} catch (IOException e) {
					System.err.println("Error: Invalid column selected");
				}
				return;
			}

			//Starts from, bottom and finds first available open space
			for (int row = 5; row >= 0; row--) {
				if (board[row][column] == 'x') {
					//Places respective piece based on turn
					if (redTurn) {
						board[row][column] = 'r';
						try {
							// send over the move that was made then swap turns
							red.out.writeObject(new Message("red", row, column, Boolean.FALSE));
							black.out.writeObject(new Message("red", row, column, Boolean.TRUE));
							redTurn = !redTurn;
						} catch (IOException e) {
							System.err.println("MakeMove error");
						}


						//Check for a win on the current piece everytime a new one is placed, sends message and returns
						//true for a win
						if(checkForWin(row, column, 'r')){
							try{
								black.out.writeObject(new Message("Red got 4 in a row and won.", MessageType.TEXT));
								red.out.writeObject(new Message("You won!"));
								red.out.writeObject(new Message("Red", MessageType.GAMEOVER));
								black.out.writeObject(new Message("Red", MessageType.GAMEOVER));
							}catch(IOException e){
								System.err.println("MakeMove error");
							}
						}
						return;
					} else {
						board[row][column] = 'b';
						// send over the move that was made then swap turns
						try {
							red.out.writeObject(new Message("black", row, column, Boolean.TRUE));
							black.out.writeObject(new Message("black", row, column, Boolean.FALSE));
							redTurn = !redTurn;
						} catch (IOException e) {
							System.err.println("MakeMove error");
						}
						if (checkForWin(row, column, 'b')){
							try{
								black.out.writeObject(new Message("You won!", MessageType.TEXT));
								red.out.writeObject(new Message("Black got 4 in a row and won."));
								red.out.writeObject(new Message("Black", MessageType.GAMEOVER));
								black.out.writeObject(new Message("Black", MessageType.GAMEOVER));
							}catch(IOException e){
								System.err.println("MakeMove error");
							}
						}
						return;
					}
				}
			}
			// Check if the board is full
			if (isBoardFull()) {
				// End the game and declare a draw
				try {
					red.out.writeObject(new Message("Draw, the board is full.", MessageType.TEXT));
					red.out.writeObject(new Message("Draw", MessageType.GAMEOVER));
					black.out.writeObject(new Message("Draw, the board is full.", MessageType.TEXT));
					black.out.writeObject(new Message("Draw", MessageType.GAMEOVER));
				} catch (IOException e) {
					System.err.println("Game Over (draw) message error");
				}
				return;
			}
			//Otherwise the column is full
			try {
				caller.out.writeObject(new Message("invalid", MessageType.MOVE));
			} catch (IOException e) {
				System.err.println("MakeMove error Col is full");
			}
		}


	}


	class ClientThread extends Thread {


		Socket connection;
		int count;
		ObjectInputStream in;
		ObjectOutputStream out;
		String username;
		GameBoard gameBoard;


		ClientThread(Socket s, int count) {
			this.connection = s;
			this.count = count;
		}

		public void updateClients(Message message) {
			switch (message.type) {
				case TEXT:
					if (message.recipient.equals("All")) {
						for (ClientThread client : clients) {
							if (client != this) {
								try {
									client.out.writeObject(message);
								} catch (Exception e) {
									System.err.println("TEXT error");
								}
							}
						}
					} else {
						ClientThread recipient = clientMap.get(message.recipient);
						if (recipient != null) {
							try {
								recipient.out.writeObject(message);
							} catch (Exception e) {
								System.err.println("TEXT error");
							}
						}
					}
					break;
				case NEWUSER:
					for (ClientThread t : clients) {
						if (this != t) {
							try {
								t.out.writeObject(message);
							} catch (Exception e) {
								System.err.println("NEWUSER Error");
							}
						}
					}
					break;
				case USERNAME:
					//Checks if name is not already taken and puts user as key and current thread as value
					if (!clientMap.containsKey(message.message)) {
						try {
							clientMap.put(message.message, this);
							this.username = message.message;
							updateClients(new Message(username, true));
							Message m = new Message("valid", MessageType.USERNAME);
							this.out.writeObject(m);
							Message n = new Message(username + " has joined!", MessageType.TEXT);
							n.recipient = "All";
							callback.accept(n);
						} catch (Exception e) {
							System.err.println("USERNAME error");
						}
					} else {
						try {
							Message invalidMsg = new Message("invalid", MessageType.USERNAME);
							this.out.writeObject(invalidMsg);
						} catch (Exception e) {
							System.err.println("USERNAME error");
						}
					}
					break;
				case JOIN:

					for (GameBoard gb : gameBoards) {
						if (gb.JoinGame(this)) {
							// messages handled in the gameboard join method
							this.gameBoard = gb;
							break;
						}
					}
					if (this.gameBoard != null) {
						break;
					}
					// if they couldn't join a game then create one
					GameBoard gb = new GameBoard(this);
					gameBoards.add(gb);
					// display that the client thread is waiting for an opponent
					Message m = new Message(this.username + " is waiting for an opponent", MessageType.TEXT);
					callback.accept(m);


					try {
						// let the thread know that they are red
						Message n = new Message("red", MessageType.JOIN);
						this.out.writeObject(n);
					} catch (Exception e) {
						System.err.println("JOIN (create gameboard) Error");
					}
					break;
				case MOVE:
					this.gameBoard.makeMove(message.column, this);
					break;
				case DISCONNECT:
					if (this.gameBoard != null) {
						ClientThread opponent;
						if (this.gameBoard.red == this) {
							opponent = this.gameBoard.black;
						} else {
							opponent = this.gameBoard.red;
						}

						try {
							// Send message to the opponent
							if (opponent != null) {
								opponent.out.writeObject(new Message("Opponent has disconnected.", MessageType.TEXT));
								opponent.out.writeObject(new Message("Opponent Disconnected", MessageType.GAMEOVER));

							}
							gameBoards.remove(this.gameBoard);
						} catch (IOException e) {
							System.err.println("Error notifying opponent about disconnection.");
						}

						// Clean up the game board
						gameBoard = null;  // Remove the reference to this player's game

					}
					clients.remove(this);
					//map iterating to find the username
					//Map.Entry iterates through both parts of the map since we need to get the username which is the key
					//And we are looking for the current thread
					for (Map.Entry<String, ClientThread> t : clientMap.entrySet()) {
						if (t.getValue() == this) {
							clientMap.entrySet().remove(t.getValue());
							break;
						}
					}
			}
		}

		public void run() {

			try {
				in = new ObjectInputStream(connection.getInputStream());
				out = new ObjectOutputStream(connection.getOutputStream());
				connection.setTcpNoDelay(true);
			} catch (Exception e) {
				System.out.println("Streams not open");
			}

			updateClients(new Message(username, true));

			while (true) {
				try {
					Message data = (Message) in.readObject();
					callback.accept(data);
					updateClients(data);
				} catch (Exception e) {
					e.printStackTrace();
					Message discon = new Message(username, false);
					callback.accept(discon);
					updateClients(discon);
					clients.remove(this);
					break;
				}
			}
		}


	}
}