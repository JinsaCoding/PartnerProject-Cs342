import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.scene.control.ListView;
/*
 * Clicker: A: I really get it    B: No idea what you are talking about
 * C: kind of following
 */

public class Server{

	int count = 1;
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	HashMap<String, ClientThread>clientMap = new HashMap<>();
	TheServer server;
	private Consumer<Message> callback;


	Server(Consumer<Message> call){

		callback = call;
		server = new TheServer();
		server.start();
	}


	public class TheServer extends Thread{

		public void run() {

			try(ServerSocket mysocket = new ServerSocket(5555);){
				System.out.println("Server is waiting for a client!");


				while(true) {

					ClientThread c = new ClientThread(mysocket.accept(), count);
					callback.accept(new Message(count, true));
					clients.add(c);
					c.start();

					count++;

				}
			}
			catch(Exception e) {
				callback.accept(new Message("Server did not launch"));
			}
		}
	}


	class ClientThread extends Thread{


		Socket connection;
		int count;
		ObjectInputStream in;
		ObjectOutputStream out;


		ClientThread(Socket s, int count){
			this.connection = s;
			this.count = count;
		}

		public void updateClients(Message message) {
			switch(message.type){
				case TEXT:
					for(ClientThread t: clients){
						if(Objects.equals(message.recipient, "All") || Objects.equals(message.recipient, Integer.toString(t.count))) {
							try {
								t.out.writeObject(message);
							} catch (Exception e) {
								System.err.println("TEXT error");
							}
						}
					}
					break;
				case NEWUSER:
					for(ClientThread t : clients) {
						if(this != t) {
							try {
								t.out.writeObject(message);
							} catch (Exception e) {
								System.err.println("NEWUSER Error");
							}
						}
					}
					break;
				case USERNAME:
					//Checks if name is not already taken and puts user as key and current thread as value
					if(!clientMap.containsKey(message.message)) {
						try {
							clientMap.put(message.message, this);
							Message m = new Message("valid", MessageType.USERNAME);
							this.out.writeObject(m);
							Message n = new Message(message.message + " has joined!", MessageType.TEXT);
							n.recipient = "All";
							callback.accept(n);
						} catch (Exception e){
							System.err.println("USERNAME error");
						}
					} else {
						try {
							Message invalidMsg = new Message("invalid", MessageType.USERNAME);
							this.out.writeObject(invalidMsg);
						} catch (Exception e){
							System.err.println("USERNAME error");
						}
					}
					break;
				case DISCONNECT:
					//map iterating to find the username
					//Map.Entry iterates through both parts of the map since we need to get the username which is the key
					//And we are looking for the current thread
					String usernameToRemove = null;
					for (Map.Entry<String, ClientThread> t : clientMap.entrySet()) {
						if (t.getValue() == this) {
							usernameToRemove = t.getKey();
							break;
						}
					}

					if (usernameToRemove != null) {
						//send removal message to all
						clientMap.remove(usernameToRemove);
						Message disconnectMsg = new Message(usernameToRemove + " has disconnected!", MessageType.TEXT);
						disconnectMsg.recipient = "All";
						callback.accept(disconnectMsg);

						for(ClientThread t : clients) {
							try {
								t.out.writeObject(disconnectMsg);
							} catch (Exception e) {
								System.err.println("DISCONNECT error");
							}
						}
					}
					break;
			}
		}

		public void run(){

			try {
				in = new ObjectInputStream(connection.getInputStream());
				out = new ObjectOutputStream(connection.getOutputStream());
				connection.setTcpNoDelay(true);
			}
			catch(Exception e) {
				System.out.println("Streams not open");
			}

			updateClients(new Message(count,true));

			while(true) {
				try {
					Message data = (Message) in.readObject();
					callback.accept(data);
					updateClients(data);
				}
				catch(Exception e) {
					e.printStackTrace();
					Message discon = new Message(count, false);
					callback.accept(discon);
					updateClients(discon);
					clients.remove(this);
					break;
				}
			}
		}//end of run


	}//end of client thread
}



	
	

	
