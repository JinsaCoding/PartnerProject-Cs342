public enum MessageType{
    TEXT, NEWUSER, USERNAME, DISCONNECT;
}
