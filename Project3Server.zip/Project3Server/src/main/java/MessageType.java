public enum MessageType{
    TEXT, NEWUSER, DISCONNECT;
}
