public enum MessageType{
    TEXT, NEWUSER, USERNAME, JOIN, DISCONNECT;
}
